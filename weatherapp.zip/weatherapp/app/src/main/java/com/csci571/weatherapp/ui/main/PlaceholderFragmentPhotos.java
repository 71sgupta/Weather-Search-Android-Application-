//package com.csci571.weatherapp.ui.main;
//
//import android.content.Context;
//import android.net.Uri;
//import android.os.Bundle;
//
//import androidx.fragment.app.Fragment;
//import androidx.recyclerview.widget.LinearLayoutManager;
//import androidx.recyclerview.widget.RecyclerView;
//
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//
//import com.android.volley.Request;
//import com.android.volley.RequestQueue;
//import com.android.volley.Response;
//import com.android.volley.VolleyError;
//import com.android.volley.toolbox.JsonObjectRequest;
//import com.android.volley.toolbox.Volley;
//import com.csci571.weatherapp.R;
//
//import org.json.JSONArray;
//import org.json.JSONException;
//import org.json.JSONObject;
//
//import java.util.ArrayList;
//
///**
// * A simple {@link Fragment} subclass.
// * Activities that contain this fragment must implement the
// * {@link photos.OnFragmentInteractionListener} interface
// * to handle interaction events.
// * Use the {@link photos#newInstance} factory method to
// * create an instance of this fragment.
// */
//public class photos extends Fragment {
//    // TODO: Rename parameter arguments, choose names that match
//    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
//    private static final String ARG_PARAM1 = "param1";
////    private static final String ARG_PARAM2 = "param2";
//
//    // TODO: Rename and change types of parameters
//    private String mParam1;
//    private String mParam2;
//    private RecyclerView mRecyclerView;
//    private photoAdapter mExampleAdapter;
//    private ArrayList<photoitem> mExampleList;
//    private RequestQueue mRequestQueue;
//
//    private OnFragmentInteractionListener mListener;
//
//    public photos() {
//        // Required empty public constructor
//    }
//
//    /**
//     * Use this factory method to create a new instance of
//     * this fragment using the provided parameters.
//     *
//     *
//     * @return A new instance of fragment photos.
//     */
//    // TODO: Rename and change types and number of parameters
//    public static photos newInstance() {
//        photos fragment = new photos();
//        Bundle args = new Bundle();
//        args.putString(ARG_PARAM1, "vvjh");
//        //args.putString(ARG_PARAM2, param2);
//        fragment.setArguments(args);
//        return fragment;
//    }
//
//    @Override
//    public void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//
//        if (getArguments() != null) {
//            mParam1 = getArguments().getString(ARG_PARAM1);
//            //mParam2 = getArguments().getString(ARG_PARAM2);
//        }
//    }
//
//    @Override
//    public View onCreateView(LayoutInflater inflater, ViewGroup container,
//                             Bundle savedInstanceState) {
//        // Inflate the layout for this fragment
//        View root = inflater.inflate(R.layout.fragment_photos, container, false);
//        mRecyclerView = root.findViewById(R.id.recycler_view);
//        mRecyclerView.setHasFixedSize(true);
//        mRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
//
//        mExampleList = new ArrayList<>();
//
//        mRequestQueue = Volley.newRequestQueue(getContext());
//        parseJSON();
//        return root;
//    }
//
//    // TODO: Rename method, update argument and hook method into UI event
//    public void onButtonPressed(Uri uri) {
//        if (mListener != null) {
//            mListener.onFragmentInteraction(uri);
//        }
//    }
//
//    @Override
//    public void onAttach(Context context) {
//        super.onAttach(context);
//        /*if (context instanceof OnFragmentInteractionListener) {
//            mListener = (OnFragmentInteractionListener) context;
//        } else {
//            throw new RuntimeException(context.toString()
//                    + " must implement OnFragmentInteractionListener");
//        }*/
//    }
//
//    @Override
//    public void onDetach() {
//        super.onDetach();
//        mListener = null;
//    }
//
//    /**
//     * This interface must be implemented by activities that contain this
//     * fragment to allow an interaction in this fragment to be communicated
//     * to the activity and potentially other fragments contained in that
//     * activity.
//     * <p>
//     * See the Android Training lesson <a href=
//     * "http://developer.android.com/training/basics/fragments/communicating.html"
//     * >Communicating with Other Fragments</a> for more information.
//     */
//    public interface OnFragmentInteractionListener {
//        // TODO: Update argument type and name
//        void onFragmentInteraction(Uri uri);
//    }
//    private void parseJSON() {
//        String url = "https://pixabay.com/api/?key=5303976-fd6581ad4ac165d1b75cc15b3&q=kitten&image_type=photo&pretty=true";
//
//        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
//                new Response.Listener<JSONObject>() {
//                    @Override
//                    public void onResponse(JSONObject response) {
//                        try {
//                            JSONArray jsonArray = response.getJSONArray("hits");
//
//                            for (int i = 0; i < jsonArray.length(); i++) {
//                                JSONObject hit = jsonArray.getJSONObject(i);
//
//                                String creatorName = hit.getString("user");
//                                String imageUrl = hit.getString("webformatURL");
//                                int likeCount = hit.getInt("likes");
//
//                                mExampleList.add(new photoitem(imageUrl, creatorName, likeCount));
//                            }
//
//                            mExampleAdapter = new photoAdapter(getContext(), mExampleList);
//                            mRecyclerView.setAdapter(mExampleAdapter);
//
//                        } catch (JSONException e) {
//                            e.printStackTrace();
//                        }
//                    }
//                }, new Response.ErrorListener() {
//            @Override
//            public void onErrorResponse(VolleyError error) {
//                error.printStackTrace();
//            }
//        });
//
//        mRequestQueue.add(request);
//    }
//}


package com.csci571.weatherapp.ui.main;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.csci571.weatherapp.Models.ForecastData;
import com.csci571.weatherapp.Models.Photo;
import com.csci571.weatherapp.R;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

/**
 * A placeholder fragment containing a simple view.
 */
public class PlaceholderFragmentPhotos extends Fragment {

    private static final String ARG_SECTION_NUMBER = "section_number";

    private PageViewModel pageViewModel;
    private static ForecastData fd;
    private RecyclerView mRecyclerView;
        private photoAdapter mExampleAdapter;
    private ArrayList<photoitem> mExampleList;
    private RequestQueue mRequestQueue;
    private static String city;
    final static Gson gson = new GsonBuilder().create();

    public static PlaceholderFragmentPhotos newInstance(String fd1,String city1) {
        PlaceholderFragmentPhotos fragment = new PlaceholderFragmentPhotos();
        Bundle bundle = new Bundle();
        Log.d("2fd", fd1);
        bundle.putString("city", city1);
        city=city1;
        fragment.setArguments(bundle);
        fd=gson.fromJson(fd1,ForecastData.class);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        pageViewModel = ViewModelProviders.of(this).get(PageViewModel.class);
        int index = 1;
        if (getArguments() != null) {
            index = getArguments().getInt(ARG_SECTION_NUMBER);
        }
        pageViewModel.setForecastData(fd);


    }

    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_photos, container, false);
        mRecyclerView = root.findViewById(R.id.recycler_view);
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        mExampleList = new ArrayList<>();

        mRequestQueue = Volley.newRequestQueue(getContext());
        parseJSON();
        return root;
    }

    private void parseJSON() {
        //String url = "https://pixabay.com/api/?key=5303976-fd6581ad4ac165d1b75cc15b3&q=kitten&image_type=photo&pretty=true";
        String citySend= URLEncoder.encode(city);
        String url="https://csci571hw9android.appspot.com/getStateSeal/"+citySend;
   //String url="https://www.googleapis.com/customsearch/v1?q="+citySend+"&cx=011635096530545692752:rjqi2wmc8h0&imgSize=huge&imgType=photo&num=8&searchType=image&key=AIzaSyB0FxzP84Mhvust-4yKwbtGp0txvWVlkxY";
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            Photo p=gson.fromJson(response.toString(),Photo.class);
                            ///JSONArray jsonArray = response.getJSONArray("hits");

                            for (int i = 0; i < p.getItems().size(); i++) {
//                                JSONObject hit = jsonArray.getJSONObject(i);
//
//                                String creatorName = hit.getString("user");
//                                String imageUrl = hit.getString("webformatURL");
//                                int likeCount = hit.getInt("likes");

                                mExampleList.add(new photoitem(p.getItems().get(i).getLink()));
                            }

                            mExampleAdapter = new photoAdapter(getContext(), mExampleList);
                            mRecyclerView.setAdapter(mExampleAdapter);

                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });

        mRequestQueue.add(request);
    }
}
