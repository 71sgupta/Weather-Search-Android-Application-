package com.csci571.weatherapp;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.csci571.weatherapp.Models.Address;
import com.csci571.weatherapp.Models.Currently;
import com.csci571.weatherapp.Models.Daily;
import com.csci571.weatherapp.Models.Datum__;
import com.csci571.weatherapp.Models.Example;
import com.csci571.weatherapp.Models.ForecastData;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.lifecycle.Observer;

import android.preference.PreferenceManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class SearchSummary extends AppCompatActivity {
    private RequestQueue mQueue;
    private ForecastData fd;
    private String searchcity;
    private String searchcitySplit;
    private CoordinatorLayout l1;
    private CoordinatorLayout l2;
    private static DecimalFormat df = new DecimalFormat("0.00");
    final Gson gson = new GsonBuilder().create();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_summary);
        Toolbar toolbar = findViewById(R.id.toolbarSS);
        l1=findViewById(R.id.firstlayout);
        l2=findViewById(R.id.secondlayout);
        l1.setVisibility(View.GONE);
        l2.setVisibility(View.VISIBLE);
        searchcity=getIntent().getStringExtra("city");
        toolbar.setTitle(searchcity);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        Log.d("city", searchcity);
        final FloatingActionButton fab = findViewById(R.id.fab);

        final SharedPreferences sharedPref1 = SearchSummary.this.getSharedPreferences("abc",Context.MODE_PRIVATE);
        final Set<String> city = sharedPref1.getStringSet("Cities",new HashSet<String>());


        searchcitySplit=searchcity.split(",")[0];
        if(city.contains(searchcitySplit)){
            fab.setImageResource(R.drawable.map_marker_minus);
        }

        String summaryData="";

        int index = 1;
        mQueue= Volley.newRequestQueue(this);
        //final String[] temp = {""};
        String tempCity="";
        try {
            tempCity = URLEncoder.encode(searchcitySplit, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        String url="https://csci571hw9android.appspot.com/test/"+tempCity;
        //String url="https://maps.googleapis.com/maps/api/geocode/json?address="+""+","+searchcitySplit+","+""+"&key=AIzaSyB0FxzP84Mhvust-4yKwbtGp0txvWVlkxY";
        Log.d("url", url);
        JsonObjectRequest req=new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    Example addr=gson.fromJson(response.toString(),Example.class);
                    Double lat=addr.getResults().get(0).getGeometry().getLocation().getLat();
                    Double lon=addr.getResults().get(0).getGeometry().getLocation().getLng();
                    //temp[0] =searchcity+","+lat+","+lon;
                    getForecastData(lat,lon);
                } catch (Exception e) {
                    Log.d("lon", e.getMessage());
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("lon", error.getMessage());
            }
        });
        mQueue.add(req);


        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
//                        .setAction("Action", null).show();



                if(city.contains(searchcitySplit)){
                    city.remove(searchcitySplit);
                    Log.d("Inside if", searchcitySplit);
                    Toast.makeText(SearchSummary.this,searchcity+" was removed from favourites.",Toast.LENGTH_SHORT).show();

                    fab.setImageResource(R.drawable.map_marker_plus);
                }
                else {
                    city.add(searchcitySplit);
                    Log.d("Inside else", searchcitySplit);
                    Toast.makeText(SearchSummary.this,searchcity+" was added to favourites.",Toast.LENGTH_SHORT).show();
                    fab.setImageResource(R.drawable.map_marker_minus);
                }

//                SharedPreferences mySPrefs = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
//                SharedPreferences.Editor editor1 = mySPrefs.edit();


                SharedPreferences.Editor editor = sharedPref1.edit();
                editor.remove("Cities");
                editor.apply();
                editor.commit();
//                editor.remove("Cities");

                editor.putStringSet("Cities", city);
                editor.apply();
                editor.commit();

            }
        });
    }

    public void getForecastData(Double lat,Double lon){
        mQueue= Volley.newRequestQueue(this);
        Log.d("latFD", lat.toString());
        Log.d("lonFD", lon.toString());
        String url="https://csci571hw9android.appspot.com/getCurrentApiData/"+lat+"/"+lon;
        //String url="http://csci571nodejsserver.appspot.com/api/getForecast?latitude="+lat+"&longitude="+lon;
        JsonObjectRequest req=new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    ForecastData fd=gson.fromJson(response.toString(),ForecastData.class);
                    Log.d("searchfd", fd.getCurrently().getSummary());
                    updateView(fd);
                    l1.setVisibility(View.VISIBLE);
                    l2.setVisibility(View.GONE);
                } catch (Exception e) {
                    Log.d("lon", e.getMessage());
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("lon", error.getMessage());
            }
        });
        mQueue.add(req);
    }

    public void updateView(ForecastData fd){
//
//        final TextView textView = findViewById(R.id.section_label);
//        final ListView listData=findViewById(R.id.list_view);
//
//
//        final CardView card3=findViewById(R.id.card_view2);
//
//
//        final CardView card1=findViewById(R.id.card_view);
//        final ImageView icon =findViewById(R.id.icon);
//        final TextView temp = findViewById(R.id.section_label);
//        final TextView summary = findViewById(R.id.summary);
//        final TextView city = findViewById(R.id.city);
//
//        final CardView card2= findViewById(R.id.card_view1);
//        final TextView humd = findViewById(R.id.humdv);
//        final TextView wind = findViewById(R.id.windv);
//        final TextView visi = findViewById(R.id.visv);
//        final TextView pres = findViewById(R.id.presv);
//
//        final List<Datum__> dailyData=new ArrayList<Datum__>();
//
//
//        final Currently cu=new Currently();
//
//                //textView.setText(s);
//                //icon.setImageResource(fd.getCurrently().getIcon());
//                temp.setText(fd1.getCurrently().getTemperature().toString());
//                summary.setText(fd1.getCurrently().getSummary());
//                city.setText(fd1.getTimezone());
//                Daily d=fd1.getDaily();
//                for (int i=0;i<d.getData().size();i++){
//                    Datum__ d2=new Datum__();
//                    Log.d("logger 224", d.getData().get(i).getTime().toString());
//                    d2.setTime(d.getData().get(i).getTime());
//                    d2.setIcon(d.getData().get(i).getIcon());
//                    d2.setTemperatureMax(d.getData().get(i).getTemperatureMax());
//                    d2.setTemperatureMin(d.getData().get(i).getTemperatureMin());
//                    dailyData.add(d2);
//                }
//
//                humd.setText(fd1.getCurrently().getHumidity().toString());
//                wind.setText(fd1.getCurrently().getWindSpeed().toString());
//                pres.setText(fd1.getCurrently().getPressure().toString());
//                visi.setText(fd1.getCurrently().getVisibility().toString());
//
//                listData.setAdapter(new ListArrayAdapter(this,dailyData ));
//
//
//        card1.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent i=new Intent(SearchSummary.this, detail_weather.class);/*
//                Bundle extras=new Bundle();
//                extras.put*/
//                Gson gson = new Gson();
//                String myJson = gson.toJson(fd);
//                Log.d("1fd", myJson);
//                i.putExtra("forecastData",myJson);
//                startActivity(i);
//            }
//        });
        final ForecastData fd1=fd;
        final TextView textView = findViewById(R.id.section_label);
        final ListView listData=findViewById(R.id.list_view);
//        spinner = (ProgressBar)root.findViewById(R.id.pbHeaderProgress);
//        spinner.setVisibility(View.VISIBLE);
        final CardView card3=findViewById(R.id.card_view2);


        final CardView card1=findViewById(R.id.card_view);
        final ImageView icon =findViewById(R.id.icon);
        final TextView temp = findViewById(R.id.section_label);
        final TextView summary = findViewById(R.id.summary);
        final TextView city = findViewById(R.id.city);

        final CardView card2=findViewById(R.id.card_view1);
        final TextView humd = findViewById(R.id.humdv);
        final TextView wind = findViewById(R.id.windv);
        final TextView visi = findViewById(R.id.visv);
        final TextView pres = findViewById(R.id.presv);

        final List<Datum__> dailyData=new ArrayList<Datum__>();


        final Currently cu=new Currently();

        String icn=fd.getCurrently().getIcon();
        if(icn.equalsIgnoreCase("clear-night")){
            icon.setImageResource(R.drawable.weather_night);
        }
        else if(icn.equalsIgnoreCase("rain")){
            icon.setImageResource(R.drawable.weather_rainy);
        }
        else if(icn.equalsIgnoreCase("sleet")){
            icon.setImageResource(R.drawable.weather_snowy_rainy);
        }
        else if(icn.equalsIgnoreCase("snow")){
            icon.setImageResource(R.drawable.weather_snowy);
        }
        else if(icn.equalsIgnoreCase("wind")){
            icon.setImageResource(R.drawable.weather_windy_variant);
        }
        else if(icn.equalsIgnoreCase("fog")){
            icon.setImageResource(R.drawable.weather_fog);
        }
        else if(icn.equalsIgnoreCase("cloudy")){
            icon.setImageResource(R.drawable.weather_cloudy);
        }
        else if(icn.equalsIgnoreCase("partly-cloudy-night")){
            icon.setImageResource(R.drawable.weather_night_partly_cloudy);
        }
        else if(icn.equalsIgnoreCase("partly-cloudy-day")){
            icon.setImageResource(R.drawable.weather_partly_cloudy);
        }
        else{
            icon.setImageResource(R.drawable.weather_sunny);
        }
        if(fd.getCurrently()!=null && fd.getCurrently().getTemperature()!=null)
            temp.setText(Integer.toString((int)Math.round(fd.getCurrently().getTemperature()))+"°"+"F");
        if(fd.getCurrently()!=null  && fd.getCurrently().getSummary()!=null && fd.getCurrently().getSummary()!="")
            summary.setText(fd.getCurrently().getSummary());

//        temp.setText(Integer.toString((int)Math.round(fd.getCurrently().getTemperature()))+"°F");
//        summary.setText(fd.getCurrently().getSummary());
        String cty="";
//        if(getArguments()!=null){
//            cty+=getArguments().getString("city")+", "+getArguments().getString("region")+", "+getArguments().getString("country");
//        }
        city.setText(searchcity);



        Daily d=fd.getDaily();
        for (int i=0;i<d.getData().size();i++){
            Datum__ d2=new Datum__();

            d2.setTime(d.getData().get(i).getTime());
            d2.setIcon(d.getData().get(i).getIcon());
            d2.setTemperatureMax(d.getData().get(i).getTemperatureMax());
            d2.setTemperatureMin(d.getData().get(i).getTemperatureMin());
            dailyData.add(d2);
        }

//        humd.setText(Long.toString(Math.round(fd.getCurrently().getHumidity()*100))+ " %");
//        wind.setText(df.format(fd.getCurrently().getWindSpeed())+ " mph");
//        pres.setText(df.format(fd.getCurrently().getPressure()).toString()+ " mb");
//        visi.setText(df.format(fd.getCurrently().getVisibility()).toString()+ " km");

        if(fd.getCurrently()!=null && fd.getCurrently().getHumidity()!=null)
            humd.setText(Long.toString(Math.round(fd.getCurrently().getHumidity()*100))+ " %");
        if(fd.getCurrently()!=null && fd.getCurrently().getWindSpeed()!=null)
            wind.setText(df.format(fd.getCurrently().getWindSpeed())+ " mph");
        if(fd.getCurrently()!=null && fd.getCurrently().getPressure()!=null)
            pres.setText(df.format(fd.getCurrently().getPressure()).toString()+ " mb");
        if(fd.getCurrently()!=null && fd.getCurrently().getVisibility()!=null)
            visi.setText(df.format(fd.getCurrently().getVisibility()).toString()+ " km");


        listData.setAdapter(new ListArrayAdapter(this,dailyData ));
        card1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(SearchSummary.this, detail_weather.class);/*
                Bundle extras=new Bundle();
                extras.put*/
                Gson gson = new Gson();
                String myJson = gson.toJson(fd1);
                Log.d("1fd", myJson);
                i.putExtra("forecastData",myJson);
                i.putExtra("city",searchcity);
                startActivity(i);
            }
        });

    }

}
