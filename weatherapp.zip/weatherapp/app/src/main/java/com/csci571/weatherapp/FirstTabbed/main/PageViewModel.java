package com.csci571.weatherapp.FirstTabbed.main;

import androidx.arch.core.util.Function;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Transformations;
import androidx.lifecycle.ViewModel;

import com.csci571.weatherapp.Models.ForecastData;

public class PageViewModel extends ViewModel {

    private MutableLiveData<ForecastData> forecastData = new MutableLiveData<>();
//    private LiveData<ForecastData> fData = Transformations.map(fData, new Function<Integer, String>() {
//        @Override
//        public String apply(Integer input) {
//            return "Hello world from section: " + input;
//        }
//    });

    public void setForecastdata(ForecastData fd) {
        forecastData.setValue(fd);
    }

    public LiveData<ForecastData> getforecastData() {
        return forecastData;
    }
}