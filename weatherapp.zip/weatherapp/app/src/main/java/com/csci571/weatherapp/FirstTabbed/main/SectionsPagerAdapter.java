package com.csci571.weatherapp.FirstTabbed.main;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;
import android.widget.Toast;


import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.fragment.app.FragmentStatePagerAdapter;


import com.csci571.weatherapp.Current_location;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * A [FragmentPagerAdapter] that returns a fragment corresponding to
 * one of the sections/tabs/pages.
 */
public class SectionsPagerAdapter extends FragmentStatePagerAdapter {

//    @StringRes
    //private static final int[] TAB_TITLES = new int[]{R.string.tab_text_1, R.string.tab_text_2};
    private final Context mContext;
    private final List<PlaceholderFragment> favLoc= new ArrayList<>();
    private final List<String> fragCity=new ArrayList<>();
    //private long baseId = 0;

    public SectionsPagerAdapter(Context context, FragmentManager fm) {
        super(fm);
        mContext = context;
    }

    @Override
    public Fragment getItem(int position) {
        // getItem is called to instantiate the fragment for the given page.
        // Return a PlaceholderFragment (defined as a static inner class below).
//return PlaceholderFragment.newInstance();
        return favLoc.get(position);
        //return PlaceholderFragment.newInstance(position + 1);
    }

//    @Nullable
//    @Override
//    public CharSequence getPageTitle(int position) {
//        return mContext.getResources().getString(TAB_TITLES[position]);
//    }

    @Override
    public int getCount() {
        // Show 2 total pages.
        return favLoc.size();
    }

    public void addTab(PlaceholderFragment frag,String city,String reg,String country){
        favLoc.add(frag);
        if(reg!="")
        fragCity.add(city+", "+reg+", "+country);
        else
            fragCity.add(city+", "+country);
    }
    public String getCity(int pos){
        return fragCity.get(pos);
    }

    public void destroyFragment(int position){
        Log.d("position", ""+position);
        favLoc.remove(position);
        String cityget=fragCity.get(position);
        fragCity.remove(position);
       SharedPreferences sharedPref1 = mContext.getSharedPreferences("abc",Context.MODE_PRIVATE);
        Set<String> city = sharedPref1.getStringSet("Cities",new HashSet<String>());
        SharedPreferences.Editor editor = sharedPref1.edit();
        editor.remove("Cities");
        editor.apply();
        editor.commit();
//                editor.remove("Cities");
        Log.d("csizeinitail", Integer.toString(city.size())+city);
        city.remove(cityget.split(",")[0]);
        Log.d("csize", Integer.toString(city.size()));
//        Set<String> saveset=new HashSet<>(fragCity);
        editor.putStringSet("Cities", city);
        editor.apply();
        editor.commit();
        //Toast.makeText(this,cityget+" was removed from favourites.",Toast.LENGTH_SHORT).show();
        //notifyChangeInPosition(1);
        notifyDataSetChanged();
    }

    public void destroyAllFragment(){
        favLoc.clear();
        fragCity.clear();
//        SharedPreferences sharedPref1 = mContext.getSharedPreferences("abc",Context.MODE_PRIVATE);
//        Set<String> city = sharedPref1.getStringSet("Cities",new HashSet<String>());
//        SharedPreferences.Editor editor = sharedPref1.edit();
//        editor.remove("Cities");
//        editor.apply();
//        editor.commit();
        notifyDataSetChanged();
    }

    @Override
    public int getItemPosition(@NonNull Object object) {
        return this.POSITION_NONE;
    }

}