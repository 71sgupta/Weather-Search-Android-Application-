package com.csci571.weatherapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.csci571.weatherapp.Models.Datum__;
import com.csci571.weatherapp.Models.ForecastData;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class ListArrayAdapter extends ArrayAdapter<Datum__> {

    private final Context context;
    private final List<Datum__> values;

    public ListArrayAdapter(Context context, List<Datum__> values) {
        super(context, R.layout.current_loc_list, values);
        this.context = context;
        this.values = values;
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View rowView = inflater.inflate(R.layout.current_loc_list, parent, false);
        TextView textView1 = (TextView) rowView.findViewById(R.id.date);
        ImageView imageView = (ImageView) rowView.findViewById(R.id.dayI);
        TextView textView2 = (TextView) rowView.findViewById(R.id.maxT);
        TextView textView3 = (TextView) rowView.findViewById(R.id.minT);
        Date date=new Date(values.get(position).getTime()*1000L);

        SimpleDateFormat sdf = new java.text.SimpleDateFormat("MM/dd/YYYY");
        textView1.setText(sdf.format(date));
        String icn=values.get(position).getIcon();
        if(icn.equalsIgnoreCase("clear-night")){
            imageView.setImageResource(R.drawable.weather_night);
        }
        else if(icn.equalsIgnoreCase("rain")){
            imageView.setImageResource(R.drawable.weather_rainy);
        }
        else if(icn.equalsIgnoreCase("sleet")){
            imageView.setImageResource(R.drawable.weather_snowy_rainy);
        }
        else if(icn.equalsIgnoreCase("snow")){
            imageView.setImageResource(R.drawable.weather_snowy);
        }
        else if(icn.equalsIgnoreCase("wind")){
            imageView.setImageResource(R.drawable.weather_windy_variant);
        }
        else if(icn.equalsIgnoreCase("fog")){
            imageView.setImageResource(R.drawable.weather_fog);
        }
        else if(icn.equalsIgnoreCase("cloudy")){
            imageView.setImageResource(R.drawable.weather_cloudy);
        }
        else if(icn.equalsIgnoreCase("partly-cloudy-night")){
            imageView.setImageResource(R.drawable.weather_night_partly_cloudy);
        }
        else if(icn.equalsIgnoreCase("partly-cloudy-day")){
            imageView.setImageResource(R.drawable.weather_partly_cloudy);
        }
        else{
            imageView.setImageResource(R.drawable.weather_sunny);
        }


        textView2.setText(Integer.toString((int)Math.round(values.get(position).getTemperatureMax())));
        textView3.setText(Integer.toString((int)Math.round(values.get(position).getTemperatureMin())));
        //imageView.setImageResource(R.drawable.rainy);

        // Change icon based on name

        return rowView;
    }
}
