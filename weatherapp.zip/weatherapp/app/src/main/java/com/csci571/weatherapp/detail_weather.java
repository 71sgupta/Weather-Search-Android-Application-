package com.csci571.weatherapp;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import com.csci571.weatherapp.Models.ForecastData;
import com.csci571.weatherapp.ui.main.PlaceholderFragment;
import com.csci571.weatherapp.ui.main.PlaceholderFragmentPhotos;
import com.csci571.weatherapp.ui.main.PlaceholderFragmentWeekly;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.tabs.TabLayout;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.viewpager.widget.ViewPager;
import androidx.appcompat.app.AppCompatActivity;

import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.csci571.weatherapp.ui.main.SectionsPagerAdapter;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class detail_weather extends AppCompatActivity {
    final static Gson gson = new GsonBuilder().create();
    String passedArg1="";
    String cit1="";
    int cnt=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        cnt++;
        setContentView(R.layout.activity_detail_weather);
        SectionsPagerAdapter sectionsPagerAdapter = new SectionsPagerAdapter(this, getSupportFragmentManager());
        final String passedArg = getIntent().getExtras().getString("forecastData");
        passedArg1=passedArg;
        Toolbar mToolbar = (Toolbar) findViewById(R.id.toolbarDW);
        mToolbar.setTitle(getIntent().getExtras().getString("city"));
        setSupportActionBar(mToolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        final String cit=getIntent().getExtras().getString("city").split(",")[0];
        cit1=cit;
//        TextView textv=findViewById(R.id.title);
//        textv.setText(cit);

        sectionsPagerAdapter.addItem(PlaceholderFragment.newInstance(passedArg));
        sectionsPagerAdapter.addItem(PlaceholderFragmentWeekly.newInstance(passedArg));
        sectionsPagerAdapter.addItem(PlaceholderFragmentPhotos.newInstance(passedArg,cit));
        //sectionsPagerAdapter.addItem(PlaceholderFragment.newInstance(passedArg));
        ViewPager viewPager = findViewById(R.id.view_pager);
        viewPager.setAdapter(sectionsPagerAdapter);
        viewPager.setOffscreenPageLimit(5);
        TabLayout tabs = findViewById(R.id.tabs);
        tabs.setupWithViewPager(viewPager);


//        FloatingActionButton fab = findViewById(R.id.fab);
//
//        fab.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
//                        .setAction("Action", null).show();
//            }
//        });

        tabs.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                tab.getIcon().setAlpha(255);
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                tab.getIcon().setAlpha(128);
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {
                tab.getIcon().setAlpha(255);
            }
        });
        //Log.d("tabcount", Integer.toString(tabs.getTabCount()));
        for(int i=0;i<tabs.getTabCount();i++){
           if(i==0){
               tabs.getTabAt(i).setIcon(R.drawable.calendar_today);
               tabs.getTabAt(i).setText("TODAY");
           }
           else if(i==1){
               tabs.getTabAt(i).setIcon(R.drawable.trending_up);
               tabs.getTabAt(i).setText("WEEKLY");
           }
           else if(i==2){
               tabs.getTabAt(i).setIcon(R.drawable.google_photos);
               tabs.getTabAt(i).setText("PHOTOS");
           }

        }
        tabs.getTabAt(0).getIcon().setAlpha(255);
        tabs.getTabAt(1).getIcon().setAlpha(128);
        tabs.getTabAt(2).getIcon().setAlpha(128);

    }


    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.twittermenu, menu);

        MenuItem searchItem = menu.findItem(R.id.action_search1);
        searchItem.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {

            @Override
            public boolean onMenuItemClick(MenuItem item) {
                ForecastData fd=gson.fromJson(passedArg1,ForecastData.class);
                String clause="Check out "+cit1+" Weather! It is "+ Math.round(fd.getCurrently().getTemperature())+"°F!"+ "&hashtags=CSCI571WeatherSearch";
                String url = "https://twitter.com/intent/tweet?text=" +clause;
                Log.d("c1", clause);

                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);
                return true;
            }
        });
        return true;

        //return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId()==android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}