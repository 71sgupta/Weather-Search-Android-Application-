//package com.csci571.weatherapp.ui.main;
//
//import android.content.Context;
//import android.graphics.Color;
//import android.net.Uri;
//import android.os.Bundle;
//
//import androidx.fragment.app.Fragment;
//
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.TextView;
//
//import com.csci571.weatherapp.Models.Currently;
//import com.csci571.weatherapp.R;
//import com.github.mikephil.charting.charts.LineChart;
//import com.github.mikephil.charting.components.Legend;
//import com.github.mikephil.charting.components.YAxis;
//import com.github.mikephil.charting.data.Entry;
//import com.github.mikephil.charting.data.LineData;
//import com.github.mikephil.charting.data.LineDataSet;
//import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;
//
//import java.util.ArrayList;
//import java.util.List;
//
///**
// * A simple {@link Fragment} subclass.
// * Activities that contain this fragment must implement the
// * {@link weekly.OnFragmentInteractionListener} interface
// * to handle interaction events.
// * Use the {@link weekly#newInstance} factory method to
// * create an instance of this fragment.
// */
//public class weekly extends Fragment {
//    // TODO: Rename parameter arguments, choose names that match
//    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
//    private static final String ARG_PARAM1 = "currentlyData";
//    //private static final String ARG_PARAM2 = "param2";
//
//    // TODO: Rename and change types of parameters
//    private String mParam1;
//    //private String mParam2;
//
//    private OnFragmentInteractionListener mListener;
//
//    public weekly() {
//        // Required empty public constructor
//    }
//
//    /**
//     * Use this factory method to create a new instance of
//     * this fragment using the provided parameters.
//     *
//     *
//     * @return A new instance of fragment weekly.
//     */
//    // TODO: Rename and change types and number of parameters
//    public static weekly newInstance() {
//        weekly fragment = new weekly();
//        Bundle args = new Bundle();
//        args.putString(ARG_PARAM1,"svdsv");
//        //args.putString(ARG_PARAM2, param2);
//        fragment.setArguments(args);
//        return fragment;
//    }
//
//    @Override
//    public void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        if (getArguments() != null) {
//            mParam1 = getArguments().getString(ARG_PARAM1);
//            //mParam2 = getArguments().getString(ARG_PARAM2);
//        }
//    }
//
//    @Override
//    public View onCreateView(LayoutInflater inflater, ViewGroup container,
//                             Bundle savedInstanceState) {
//        // Inflate the layout for this fragment
//        View root = inflater.inflate(R.layout.fragment_weekly, container, false);
//        final LineChart chartView = root.findViewById(R.id.charView);
//        List<Entry> valsComp1 = new ArrayList<Entry>();
//        List<Entry> valsComp2 = new ArrayList<Entry>();
//        Entry c1e1 = new Entry(0f, 120000f); // 0 == quarter 1
//        valsComp1.add(c1e1);
//        Entry c1e2 = new Entry(1f, 140000f); // 1 == quarter 2 ...
//        valsComp1.add(c1e2);
//        // and so on ...
//        Entry c2e1 = new Entry(0f, 120000f); // 0 == quarter 1
//        valsComp2.add(c2e1);
//        Entry c2e2 = new Entry(2f, 115000f); // 1 == quarter 2 ...
//        LineDataSet setComp1 = new LineDataSet(valsComp1, "Company 1");
//        setComp1.setAxisDependency(YAxis.AxisDependency.LEFT);
//        setComp1.setValueTextColor(Color.GREEN);
//        LineDataSet setComp2 = new LineDataSet(valsComp2, "Company 2");
//        setComp2.setValueTextColor(Color.BLUE);
//        setComp2.setAxisDependency(YAxis.AxisDependency.LEFT);
//        List<ILineDataSet> dataSets = new ArrayList<ILineDataSet>();
//        dataSets.add(setComp1);
//        dataSets.add(setComp2);
//        LineData data = new LineData(dataSets);
//        chartView.setData(data);
//        Legend l = chartView.getLegend();
//        l.setTextColor(Color.WHITE);
//        chartView.invalidate(); // refresh
//        return root;
//    }
//
//    // TODO: Rename method, update argument and hook method into UI event
//    public void onButtonPressed(Uri uri) {
//        if (mListener != null) {
//            mListener.onFragmentInteraction(uri);
//        }
//    }
//
////    @Override
////    public void onAttach(Context context) {
////        super.onAttach(context);
////        if (context instanceof OnFragmentInteractionListener) {
////            mListener = (OnFragmentInteractionListener) context;
////        } else {
////            throw new RuntimeException(context.toString()
////                    + " must implement OnFragmentInteractionListener");
////        }
////    }
//
//    @Override
//    public void onDetach() {
//        super.onDetach();
//        mListener = null;
//    }
//
//    /**
//     * This interface must be implemented by activities that contain this
//     * fragment to allow an interaction in this fragment to be communicated
//     * to the activity and potentially other fragments contained in that
//     * activity.
//     * <p>
//     * See the Android Training lesson <a href=
//     * "http://developer.android.com/training/basics/fragments/communicating.html"
//     * >Communicating with Other Fragments</a> for more information.
//     */
//    public interface OnFragmentInteractionListener {
//        // TODO: Update argument type and name
//        void onFragmentInteraction(Uri uri);
//    }
//}



package com.csci571.weatherapp.ui.main;

        import android.graphics.Color;
        import android.os.Bundle;
        import android.util.Log;
        import android.view.LayoutInflater;
        import android.view.View;
        import android.view.ViewGroup;
        import android.widget.ImageView;
        import android.widget.TextView;

        import androidx.annotation.Nullable;
        import androidx.annotation.NonNull;
        import androidx.fragment.app.Fragment;
        import androidx.lifecycle.Observer;
        import androidx.lifecycle.ViewModelProviders;

        import com.csci571.weatherapp.Models.ForecastData;
        import com.csci571.weatherapp.R;

        import com.github.mikephil.charting.charts.LineChart;
        import com.github.mikephil.charting.components.AxisBase;
        import com.github.mikephil.charting.components.Legend;
        import com.github.mikephil.charting.components.YAxis;
        import com.github.mikephil.charting.data.Entry;
        import com.github.mikephil.charting.data.LineData;
        import com.github.mikephil.charting.data.LineDataSet;
        import com.github.mikephil.charting.formatter.ValueFormatter;
        import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;
        import com.google.gson.Gson;
        import com.google.gson.GsonBuilder;

        import java.util.ArrayList;
        import java.util.List;

/**
 * A placeholder fragment containing a simple view.
 */
public class PlaceholderFragmentWeekly extends Fragment {

    private static final String ARG_SECTION_NUMBER = "section_number";

    private PageViewModel pageViewModel;
    private static ForecastData fd;
    final static Gson gson = new GsonBuilder().create();

    public static PlaceholderFragmentWeekly newInstance(String fd1) {
        PlaceholderFragmentWeekly fragment = new PlaceholderFragmentWeekly();
        Bundle bundle = new Bundle();
        Log.d("2fd", fd1);
        bundle.putInt(ARG_SECTION_NUMBER, 0);
        fragment.setArguments(bundle);
        fd=gson.fromJson(fd1,ForecastData.class);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        pageViewModel = ViewModelProviders.of(this).get(PageViewModel.class);
        int index = 1;
        if (getArguments() != null) {
            index = getArguments().getInt(ARG_SECTION_NUMBER);
        }
        pageViewModel.setForecastData(fd);


    }

    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_weekly, container, false);
        TextView text=root.findViewById(R.id.summary);
        ImageView icon=root.findViewById(R.id.icon1);
        String icn=fd.getDaily().getIcon();
        if(icn.equalsIgnoreCase("clear-night")){
            icon.setImageResource(R.drawable.weather_night);
        }
        else if(icn.equalsIgnoreCase("rain")){
            icon.setImageResource(R.drawable.weather_rainy);
        }
        else if(icn.equalsIgnoreCase("sleet")){
            icon.setImageResource(R.drawable.weather_snowy_rainy);
        }
        else if(icn.equalsIgnoreCase("snow")){
            icon.setImageResource(R.drawable.weather_snowy);
        }
        else if(icn.equalsIgnoreCase("wind")){
            icon.setImageResource(R.drawable.weather_windy_variant);
        }
        else if(icn.equalsIgnoreCase("fog")){
            icon.setImageResource(R.drawable.weather_fog);
        }
        else if(icn.equalsIgnoreCase("cloudy")){
            icon.setImageResource(R.drawable.weather_cloudy);
        }
        else if(icn.equalsIgnoreCase("partly-cloudy-night")){
            icon.setImageResource(R.drawable.weather_night_partly_cloudy);
        }
        else if(icn.equalsIgnoreCase("partly-cloudy-day")){
            icon.setImageResource(R.drawable.weather_partly_cloudy);
        }
        else{
            icon.setImageResource(R.drawable.weather_sunny);
        }

        text.setText(fd.getDaily().getSummary());


        final LineChart chartView = root.findViewById(R.id.charView);
        List<Entry> tempMax = new ArrayList<Entry>();
        List<Entry> tempMin = new ArrayList<Entry>();
        for(int i=0;i<fd.getDaily().getData().size();i++){
            Entry maxV = new Entry(i, (float) fd.getDaily().getData().get(i).getTemperatureMax());
            Entry minV = new Entry(i, (float) fd.getDaily().getData().get(i).getTemperatureMin());
            tempMax.add(maxV);
            tempMin.add(minV);
        }

        LineDataSet setComp1 = new LineDataSet(tempMax, "Maximum Temperature");
        setComp1.setAxisDependency(YAxis.AxisDependency.LEFT);
        setComp1.setColor(Color.YELLOW);
        LineDataSet setComp2 = new LineDataSet(tempMin, "Minimum Temperature");
        setComp2.setColor(Color.rgb(128,0,128));
        setComp2.setAxisDependency(YAxis.AxisDependency.LEFT);
        final String[] quarters = new String[] { "0", "1", "2", "3", "4", "5", "6", "7" };
        ValueFormatter xValues = new ValueFormatter() {
            @Override
            public String getAxisLabel(float value, AxisBase axis) {
                return quarters[(int) value];
            }
        };
        List<ILineDataSet> dataSets = new ArrayList<ILineDataSet>();
        dataSets.add(setComp2);
        dataSets.add(setComp1);
        LineData data = new LineData(dataSets);
        chartView.setData(data);
        Legend l = chartView.getLegend();
        l.setTextColor(Color.WHITE);
        l.setTextSize(12f);
        chartView.getAxisLeft().setTextColor(Color.WHITE); // left y-axis
        chartView.getAxisRight().setTextColor(Color.WHITE);
        chartView.getAxisRight().setGranularity(10f);
        chartView.getXAxis().setTextColor(Color.WHITE);
        chartView.getXAxis().setGranularity(1);
        chartView.getAxisLeft().setTextSize(9f);
        chartView.getAxisLeft().setGranularity(10f);
        chartView.getAxisRight().setTextSize(9f);
        chartView.getXAxis().setTextSize(9f);
        chartView.getXAxis().setDrawGridLines(false);
        chartView.getAxisLeft().setDrawGridLines(false);
        chartView.getAxisRight().setDrawGridLines(false);
        //chartView.getXAxis().setGranularity(1);
        chartView.getXAxis().setValueFormatter(xValues);
        chartView.invalidate(); // refresh
        return root;
    }
}