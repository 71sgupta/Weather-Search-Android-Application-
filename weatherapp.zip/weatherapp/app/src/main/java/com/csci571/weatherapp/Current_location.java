package com.csci571.weatherapp;

import android.app.SearchManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.csci571.weatherapp.FirstTabbed.main.PlaceholderFragment;
import com.csci571.weatherapp.Models.CityModel;
import com.csci571.weatherapp.Models.Example;
import com.csci571.weatherapp.Models.ForecastData;
import com.csci571.weatherapp.Models.Result;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.tabs.TabLayout;

import androidx.appcompat.widget.Toolbar;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.content.ContextCompat;
import androidx.core.view.MenuItemCompat;
import androidx.viewpager.widget.ViewPager;
import androidx.appcompat.app.AppCompatActivity;

import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.appcompat.widget.SearchView;


import com.csci571.weatherapp.FirstTabbed.main.SectionsPagerAdapter;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Current_location extends AppCompatActivity {
    private FloatingActionButton fab;
    private RequestQueue mQueue;
    private RequestQueue mQueue1;
    final ForecastData[] fd = {new ForecastData()};

    SectionsPagerAdapter sectionsPagerAdapter;
    SearchView searchView;
    SearchView.SearchAutoComplete searchAutoComplete ;
    private ProgressBar spinner;
    private CoordinatorLayout l1;
    private CoordinatorLayout l2;

    final Gson gson = new GsonBuilder().create();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        requestWindowFeature(Window.FEATURE_INDETERMINATE_PROGRESS);
//        setProgressBarIndeterminateVisibility(true);
        setContentView(R.layout.activity_current_location);

        l1=findViewById(R.id.firstlayout);
        l2=findViewById(R.id.secondlayout);
        l1.setVisibility(View.GONE);
        l2.setVisibility(View.VISIBLE);
         sectionsPagerAdapter = new SectionsPagerAdapter(this, getSupportFragmentManager());


        callIpApi();
        final ViewPager viewPager = findViewById(R.id.view_pager);



        TabLayout tabs = findViewById(R.id.tabs);
        tabs.setupWithViewPager(viewPager,true);
        fab=findViewById(R.id.fab);

        Intent intent = getIntent();
        Toolbar toolbar=findViewById(R.id.toolbar);
        toolbar.setTitle("Weather App");
        setSupportActionBar(toolbar);

        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                if(position==0) {
                    fab.setVisibility(View.INVISIBLE);
                }
                else {
                    fab.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onPageSelected(int position) {

            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });

        if (Intent.ACTION_SEARCH.equals(intent.getAction())) {
            String query = intent.getStringExtra(SearchManager.QUERY);
            Log.d("query", query);
            //doMySearch(query);
        }
        //fab.setImageResource(R.drawable.rainy);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

               /* SharedPreferences sharedPref = Current_location.this.getPreferences(Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPref.edit();
                SharedPreferences sharedPref1 = Current_location.this.getPreferences(Context.MODE_PRIVATE);
                Set<String> city = sharedPref1.getStringSet("Cities",new HashSet<String>());
                city.add("sdasd");
                Log.d("n1", city.toString());
                editor.putStringSet("Cities", city);
                editor.commit();


                fab.setImageDrawable(ContextCompat.getDrawable(getApplicationContext(), R.drawable.ic_launcher_foreground));*/




//                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
//                        .setAction("Action", null).show();
                Toast.makeText(Current_location.this,sectionsPagerAdapter.getCity(viewPager.getCurrentItem())+" was removed from favourites.",Toast.LENGTH_SHORT).show();

                sectionsPagerAdapter.destroyFragment(viewPager.getCurrentItem());


            }
        });


        viewPager.setAdapter(sectionsPagerAdapter);
//        setProgressBarIndeterminateVisibility(false);


    }

    @Override
    protected void onResume() {
        super.onResume();
        sectionsPagerAdapter.destroyAllFragment();
//        sectionsPagerAdapter.notifyDataSetChanged();
//        SharedPreferences sharedPref1 = Current_location.this.getSharedPreferences("abc",Context.MODE_PRIVATE);
//        Set<String> city = sharedPref1.getStringSet("Cities",new HashSet<String>());
//        //callIpApi();
//        for(String c:city){
//            Log.d("city", c);
//           getCityLatLong(c);
//        }

        //callIpApi();

    }

    public void getCityLatLong(String citi){
        mQueue= Volley.newRequestQueue(this);
        Log.d("city getcitylatlonf", citi);
        String  citi1= null;
        try {
            citi1 = URLEncoder.encode(citi, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        String url="https://csci571hw9android.appspot.com/test/"+citi1;
        //String url="https://maps.googleapis.com/maps/api/geocode/json?address="+""+","+citi1+","+""+"&key=AIzaSyB0FxzP84Mhvust-4yKwbtGp0txvWVlkxY";
        //String url="http://csci571nodejsserver.appspot.com/api/getForecast?latitude=34.0322&longitude=-118.2836";
        Log.d("google api url", url);
        final String[] lat = {""};
        final String[] lon = {""};
        final String[] url1 = {""};
        JsonObjectRequest req=new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    //JSONObject j=response.getJSONObject();
                    Log.d("new lat", "hello000000000000");
                    Example addr=gson.fromJson(response.toString(),Example.class);
                    Double lat=addr.getResults().get(0).getGeometry().getLocation().getLat();
                    Double lon=addr.getResults().get(0).getGeometry().getLocation().getLng();
                    String cityPanel=addr.getResults().get(0).getFormattedAddress();
                    Log.d("new city panel", cityPanel);
                    String[] cityArray=cityPanel.split(",");
//                    lat[0] =response.getString("lat");
//                    lon[0] =response.getString("lon");
                    final String[] city={""};
                    final String[] country={""};
                    final String[] region={""};
                    if(cityArray.length==2){
                        city[0]=cityArray[0];
                        region[0]="";
                        country[0]=cityArray[1];
                    }
                    else {
                        city[0] = cityArray[0];
                        region[0] = cityArray[1];
                        country[0] = cityArray[2];
                    }
                    Log.d("lat new", lat.toString());
                    Log.d("lonnew ", lon.toString());
                   //url1[0] ="http://csci571nodejsserver.appspot.com/api/getForecast?latitude="+lat+"&longitude="+lon;
                    url1[0]="https://csci571hw9android.appspot.com/getCurrentApiData/"+lat+"/"+lon;
                    Log.d("url", url1[0]);
                    Log.d("url454567687", url1[0]);
                    getForecastApiSharedPref(url1[0],city[0],country[0],region[0]);

//                    final Gson gson = new GsonBuilder().create();
//                    String lat=response.getString("latitude");
//                    String lon=response.getString("longitude");
//                    String temp="";
//                    fd[0] =gson.fromJson(response.toString(),ForecastData.class);
//
//                    Log.d("lat011111111111", lat);
//                    Log.d("lon0555555555", fd[0].getCurrently().getSummary());
//                    sectionsPagerAdapter.addTab(PlaceholderFragment.newInstance(fd[0]));
//                    //sectionsPagerAdapter.addTab(PlaceholderFragment.newInstance(fd[0],city[0],region[0],country[0]));
//                    sectionsPagerAdapter.notifyDataSetChanged();


                    //return getForecastApi(url1[0]);
                } catch (Exception e) {
                    Log.d("lon", e.getMessage());
                    //e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("lon", error.getMessage());
            }
        });
        mQueue.add(req);



//




        //Log.d("outside create", "onOutside: ");
    }

    public void callIpApi(){
        mQueue= Volley.newRequestQueue(this);
        Log.d("inside callapi", "callapi: ");
        String url="http://ip-api.com/json";
        //String url="http://csci571nodejsserver.appspot.com/api/getForecast?latitude=34.0322&longitude=-118.2836";
        final String[] lat = {""};
        final String[] lon = {""};
        final String[] url1 = {""};
        JsonObjectRequest req=new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    //JSONObject j=response.getJSONObject();
                    Log.d("lat011111111111", "hello");

                    lat[0] =response.getString("lat");
                    lon[0] =response.getString("lon");
                    final String[] city={""};
                    final String[] country={""};
                    final String[] region={""};
                    city[0]=response.getString("city");
                    region[0]=response.getString("region");
                    country[0]=response.getString("countryCode");
                    Log.d("lat0", lat[0]);
                    Log.d("lon0", lon[0]);
                    //url1[0] ="http://csci571nodejsserver.appspot.com/api/getForecast?latitude="+lat[0]+"&longitude="+lon[0];
                    url1[0]="https://csci571hw9android.appspot.com/getCurrentApiData/"+lat[0]+"/"+lon[0];
                    Log.d("url", url1[0]);
                    Log.d("url454567687", url1[0]);
                    getForecastApi(url1[0],city[0],country[0],region[0]);

//                    final Gson gson = new GsonBuilder().create();
//                    String lat=response.getString("latitude");
//                    String lon=response.getString("longitude");
//                    String temp="";
//                    fd[0] =gson.fromJson(response.toString(),ForecastData.class);
//
//                    Log.d("lat011111111111", lat);
//                    Log.d("lon0555555555", fd[0].getCurrently().getSummary());
//                    sectionsPagerAdapter.addTab(PlaceholderFragment.newInstance(fd[0]));
//                    //sectionsPagerAdapter.addTab(PlaceholderFragment.newInstance(fd[0],city[0],region[0],country[0]));
//                    sectionsPagerAdapter.notifyDataSetChanged();


                    //return getForecastApi(url1[0]);
                } catch (JSONException e) {
                    Log.d("lon", e.getMessage());
                    //e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("lon", error.getMessage());
            }
        });
        mQueue.add(req);



//




        //Log.d("outside create", "onOutside: ");
    }


    public void getForecastApi(String url,final String city,final String country,final String region){
        final Gson gson = new GsonBuilder().create();
        mQueue1= Volley.newRequestQueue(this);
        Log.d("lat011111111111", "dgfsfdv");
        JsonObjectRequest req1=new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    //JSONObject j=response.getJSONObject();

                    String lat=response.getString("latitude");
                    String lon=response.getString("longitude");
                    fd[0] =gson.fromJson(response.toString(),ForecastData.class);

                    Log.d("lat011111111111", lat);
                    Log.d("lon0555555555", fd[0].getCurrently().getSummary());

                    sectionsPagerAdapter.addTab(PlaceholderFragment.newInstance(fd[0],city,region,country),city,region,country);
                    sectionsPagerAdapter.notifyDataSetChanged();
                    callSharedPreference();

                } catch (JSONException e) {
                    Log.d("lon", e.getMessage());
                    //e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("lon", error.getMessage());
            }
        });
        mQueue1.add(req1);

        //return fd[0];
    }


    public void getForecastApiSharedPref(String url,final String city,final String country,final String region){
        final Gson gson = new GsonBuilder().create();
        mQueue1= Volley.newRequestQueue(this);
        Log.d("lat011111111111", "dgfsfdv");
        JsonObjectRequest req1=new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    //JSONObject j=response.getJSONObject();

                    String lat=response.getString("latitude");
                    String lon=response.getString("longitude");
                    fd[0] =gson.fromJson(response.toString(),ForecastData.class);

                    Log.d("lat011111111111", lat);
                    Log.d("lon0555555555", fd[0].getCurrently().getSummary());

                    sectionsPagerAdapter.addTab(PlaceholderFragment.newInstance(fd[0],city,region,country),city,region,country);
                    l1.setVisibility(View.VISIBLE);
                    l2.setVisibility(View.GONE);
                    sectionsPagerAdapter.notifyDataSetChanged();

                    //callSharedPreference();
                } catch (JSONException e) {
                    Log.d("lon", e.getMessage());
                    //e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("lon", error.getMessage());
            }
        });
        mQueue1.add(req1);

        //return fd[0];
    }

    public void callSharedPreference(){
        SharedPreferences sharedPref1 = Current_location.this.getSharedPreferences("abc",Context.MODE_PRIVATE);
        Set<String> city = sharedPref1.getStringSet("Cities",new HashSet<String>());
        Log.d("city size", Integer.toString(city.size()));
        if(city.size()==0){
            l1.setVisibility(View.VISIBLE);
            l2.setVisibility(View.GONE);
        }
        for(String c:city){
            Log.d("city size", c);
            getCityLatLong(c);
        }
    }
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu, menu);

        MenuItem searchItem = menu.findItem(R.id.action_search);
         searchView = (SearchView) searchItem.getActionView();
       searchAutoComplete = (SearchView.SearchAutoComplete)searchView.findViewById(androidx.appcompat.R.id.search_src_text);
//        SearchManager searchManager = (SearchManager) Current_location.this.getSystemService(Context.SEARCH_SERVICE);
//
//        SearchView searchView = null;
//        if (searchItem != null) {
//            searchView = (SearchView)
//        }
//        if (searchView != null) {
//            searchView.setSearchableInfo(searchManager.getSearchableInfo(Current_location.this.getComponentName()));
//        }
        //city call
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {

                Intent i=new Intent(Current_location.this,SearchSummary.class);
                i.putExtra("city",query);

                startActivity(i);
                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                Log.d("newText", newText);
                if(!(newText.equals("") || newText==null))
                    cityApiCall(newText);
                return true;
            }
        });

//        String dataArr[] = {"Apple" , "Amazon" , "Amd", "Microsoft", "Microwave", "MicroNews", "Intel", "Intelligence"};
//        ArrayAdapter<String> newsAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_dropdown_item_1line, dataArr);
//        searchAutoComplete.setAdapter(newsAdapter);

        searchAutoComplete.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int itemIndex, long id) {
                String queryString=(String)adapterView.getItemAtPosition(itemIndex);
                searchAutoComplete.setText("" + queryString);
                Log.d("Search query", queryString);
//                Toast.makeText(Current_location.this, "you clicked " + queryString, Toast.LENGTH_LONG).show();

            }
        });

        return super.onCreateOptionsMenu(menu);
    }
    public void cityApiCall(String city){
        Log.d("SHIVANGI12", "drftjhjhll");
        try {
            city = URLEncoder.encode(city, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        String url="https://csci571hw9android.appspot.com/getCity/"+city;
       // String url="https://maps.googleapis.com/maps/api/place/autocomplete/json?input="+city+"&types=(cities)&language=en&key=AIzaSyB0FxzP84Mhvust-4yKwbtGp0txvWVlkxY";
        //String url="https://maps.googleapis.com/maps/api/place/autocomplete/json?input=" + city + "&types=(cities)&language=en&key=AIzaSyAhMYTyLJGsZJCuorxANuek0iYviW5mFEg";
        final Gson gson = new GsonBuilder().create();
        mQueue1= Volley.newRequestQueue(this);
        final List<String> res=new ArrayList<String>();
        Log.d("SHIVANGI12", url);
        //Log.d("lat011111111111", "dgfsfdv");
        JsonObjectRequest req1=new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {

                    CityModel cmodel =gson.fromJson(response.toString(),CityModel.class);
                    for(int i=0;i<cmodel.getPredictions().size();i++){
                        res.add(cmodel.getPredictions().get(i).getDescription());
                    }


                    //String dataArr[] = {"Apple" , "Amazon" , "Amd", "Microsoft", "Microwave", "MicroNews", "Intel", "Intelligence"};
                    ArrayAdapter<String> newsAdapter = new ArrayAdapter<String>(getApplicationContext(), R.layout.autocomp, res);
                   // ArrayAdapter<String> newsAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_dropdown_item_1line, dataArr);
                    searchAutoComplete.setDropDownBackgroundResource(R.color.colorView);
                    searchAutoComplete.setBackgroundColor(Color.rgb(63,60,60));
                    searchAutoComplete.setAdapter(newsAdapter);



                } catch (Exception e) {
                    Log.d("lon", e.getMessage());
                    //e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("lon", error.getMessage());
            }
        });
        mQueue1.add(req1);
       // return res;
    }
}