package com.csci571.weatherapp.FirstTabbed.main;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.csci571.weatherapp.Current_location;
import com.csci571.weatherapp.ListArrayAdapter;
import com.csci571.weatherapp.Models.Currently;
import com.csci571.weatherapp.Models.Daily;
import com.csci571.weatherapp.Models.Datum__;
import com.csci571.weatherapp.Models.ForecastData;
import com.csci571.weatherapp.R;
import com.csci571.weatherapp.detail_weather;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * A placeholder fragment containing a simple view.
 */
public class PlaceholderFragment extends Fragment {

    private static final String ARG_SECTION_NUMBER = "section_number";
    private ProgressBar spinner;
    final static Gson gson = new GsonBuilder().create();
    private static DecimalFormat df = new DecimalFormat("0.00");
    private PageViewModel pageViewModel;
    private RequestQueue mQueue;
    private  ForecastData fd;
    public static PlaceholderFragment newInstance(ForecastData fd1,String city,String region,String country) {
        PlaceholderFragment fragment = new PlaceholderFragment();
        Bundle bundle = new Bundle();
        bundle.putString("city", city);
        bundle.putString("region", region);
        bundle.putString("country", country);
        String temp=gson.toJson(fd1);
        bundle.putString("fdata",temp);
        fragment.setArguments(bundle);
        Log.d("city", city);
        //fd=fd1;
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //String myJson = gson.toJson();
        fd=gson.fromJson(getArguments().getString("fdata"),ForecastData.class);
        pageViewModel = ViewModelProviders.of(this).get(PageViewModel.class);


        pageViewModel.setForecastdata(fd);
//
//
//        String summaryData="";

        int index = 1;
//        mQueue= Volley.newRequestQueue(getContext());
//        Log.d("inside create", "onCreate: ");
//        String url="http://csci571nodejsserver.appspot.com/api/getForecast?latitude=34.0262195&longitude=-118.2877426";
//        JsonObjectRequest req=new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
//            @Override
//            public void onResponse(JSONObject response) {
//                try {
//                    //JSONObject j=response.getJSONObject();
//                    String lat=response.getString("latitude");
//                    String lon=response.getString("longitude");
//
//
//                    fd=gson.fromJson(response.toString(),ForecastData.class);
//                    Log.d("FD", fd.toString());
//                    pageViewModel.setForecastdata(fd);
//                    // JSONObject j=response.getJSONObject("lon");
//                } catch (JSONException e) {
//                    Log.d("lon", e.getMessage());
//                    e.printStackTrace();
//                }
//            }
//        }, new Response.ErrorListener() {
//            @Override
//            public void onErrorResponse(VolleyError error) {
//                Log.d("lon", error.getMessage());
//            }
//        });
//        mQueue.add(req);
//        Log.d("outside create", "onOutside: ");
//        if (getArguments() != null) {
//            index = getArguments().getInt(ARG_SECTION_NUMBER);
//        }
        //pageViewModel.setIndex(index);
    }

    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_current_location, container, false);
        //LiveData<ForecastData> fd=pageViewModel.getforecastData();
        String myJson = gson.toJson(fd);
        fd=gson.fromJson(myJson,ForecastData.class);
        Log.d("new fd", fd.getCurrently().getSummary());
        final TextView textView = root.findViewById(R.id.section_label);
        final ListView listData=root.findViewById(R.id.list_view);

        final CardView card3=root.findViewById(R.id.card_view2);


        final CardView card1=root.findViewById(R.id.card_view);
        final ImageView icon =root.findViewById(R.id.icon);
        final TextView temp = root.findViewById(R.id.section_label);
        final TextView summary = root.findViewById(R.id.summary);
        final TextView city = root.findViewById(R.id.city);

        final CardView card2=root.findViewById(R.id.card_view1);
        final TextView humd = root.findViewById(R.id.humdv);
        final TextView wind = root.findViewById(R.id.windv);
        final TextView visi = root.findViewById(R.id.visv);
        final TextView pres = root.findViewById(R.id.presv);

        final List<Datum__> dailyData=new ArrayList<Datum__>();
        final String[] ctyn = {""};
        final Currently cu=new Currently();
        pageViewModel.getforecastData().observe(this, new Observer<ForecastData>() {
            @Override
            public void onChanged(@Nullable ForecastData fd) {
                //textView.setText(s);
                String icn=fd.getCurrently().getIcon();
                if(icn.equalsIgnoreCase("clear-night")){
                    icon.setImageResource(R.drawable.weather_night);
                }
                else if(icn.equalsIgnoreCase("rain")){
                    icon.setImageResource(R.drawable.weather_rainy);
                }
                else if(icn.equalsIgnoreCase("sleet")){
                    icon.setImageResource(R.drawable.weather_snowy_rainy);
                }
                else if(icn.equalsIgnoreCase("snow")){
                    icon.setImageResource(R.drawable.weather_snowy);
                }
                else if(icn.equalsIgnoreCase("wind")){
                    icon.setImageResource(R.drawable.weather_windy_variant);
                }
                else if(icn.equalsIgnoreCase("fog")){
                    icon.setImageResource(R.drawable.weather_fog);
                }
                else if(icn.equalsIgnoreCase("cloudy")){
                    icon.setImageResource(R.drawable.weather_cloudy);
                }
                else if(icn.equalsIgnoreCase("partly-cloudy-night")){
                    icon.setImageResource(R.drawable.weather_night_partly_cloudy);
                }
                else if(icn.equalsIgnoreCase("partly-cloudy-day")){
                    icon.setImageResource(R.drawable.weather_partly_cloudy);
                }
                else{
                    icon.setImageResource(R.drawable.weather_sunny);
                }
                if(fd.getCurrently()!=null && fd.getCurrently().getTemperature()!=null)
                temp.setText(Integer.toString((int)Math.round(fd.getCurrently().getTemperature()))+"°"+"F");
                if(fd.getCurrently()!=null  && fd.getCurrently().getSummary()!=null && fd.getCurrently().getSummary()!="")
                summary.setText(fd.getCurrently().getSummary());
                String cty="";
                if(getArguments()!=null){
                    if(getArguments().getString("region")!="")
                    cty+=getArguments().getString("city")+", "+getArguments().getString("region")+", "+getArguments().getString("country");
                    else
                        cty+=getArguments().getString("city")+", "+getArguments().getString("country");
                }
                city.setText(cty);
                ctyn[0] =cty;


                Daily d=fd.getDaily();
                for (int i=0;i<d.getData().size();i++){
                    Datum__ d2=new Datum__();

                    d2.setTime(d.getData().get(i).getTime());
                    d2.setIcon(d.getData().get(i).getIcon());
                    d2.setTemperatureMax(d.getData().get(i).getTemperatureMax());
                    d2.setTemperatureMin(d.getData().get(i).getTemperatureMin());
                    dailyData.add(d2);
                }
                if(fd.getCurrently()!=null && fd.getCurrently().getHumidity()!=null)
                humd.setText(Long.toString(Math.round(fd.getCurrently().getHumidity()*100))+ " %");
                if(fd.getCurrently()!=null && fd.getCurrently().getWindSpeed()!=null)
                wind.setText(df.format(fd.getCurrently().getWindSpeed())+ " mph");
                if(fd.getCurrently()!=null && fd.getCurrently().getPressure()!=null)
                pres.setText(df.format(fd.getCurrently().getPressure()).toString()+ " mb");
                if(fd.getCurrently()!=null && fd.getCurrently().getVisibility()!=null)
                visi.setText(df.format(fd.getCurrently().getVisibility()).toString()+ " km");

                listData.setAdapter(new ListArrayAdapter(getContext(),dailyData ));

            }
        });

        card1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getContext(), detail_weather.class);/*
                Bundle extras=new Bundle();
                extras.put*/
                Gson gson = new Gson();
                String myJson = gson.toJson(fd);
                Log.d("1fd", myJson);
                i.putExtra("forecastData",myJson);
                i.putExtra("city",ctyn[0]);
                startActivity(i);
            }
        });

        return root;
    }


}