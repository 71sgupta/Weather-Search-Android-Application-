package com.csci571.weatherapp.ui.main;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.csci571.weatherapp.Models.ForecastData;
import com.csci571.weatherapp.R;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

/**
 * A placeholder fragment containing a simple view.
 */
public class PlaceholderFragment extends Fragment {

    private static final String ARG_SECTION_NUMBER = "section_number";

    private PageViewModel pageViewModel;
    private static ForecastData fd;
    final static Gson gson = new GsonBuilder().create();
    private static DecimalFormat df = new DecimalFormat("0.00");

    public static PlaceholderFragment newInstance(String fd1)  {
        PlaceholderFragment fragment = new PlaceholderFragment();
        Bundle bundle = new Bundle();
        Log.d("2fd", fd1);

        bundle.putInt(ARG_SECTION_NUMBER, 0);
        fragment.setArguments(bundle);
        fd=gson.fromJson(fd1,ForecastData.class);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        pageViewModel = ViewModelProviders.of(this).get(PageViewModel.class);
        int index = 1;
        if (getArguments() != null) {
            index = getArguments().getInt(ARG_SECTION_NUMBER);
        }
        pageViewModel.setForecastData(fd);
    }

    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_detail_weather, container, false);
        final TextView wind = root.findViewById(R.id.wind);
        final TextView pres = root.findViewById(R.id.pres);
        final TextView prec = root.findViewById(R.id.prec);
        final TextView temp = root.findViewById(R.id.temp);
        final TextView summ = root.findViewById(R.id.summ);
        final TextView hum = root.findViewById(R.id.hum);
        final TextView visi = root.findViewById(R.id.vis);
        final TextView cloud = root.findViewById(R.id.cloud);
        final TextView ozone = root.findViewById(R.id.ozone);
        final ImageView icon=root.findViewById(R.id.icon8);


        pageViewModel.getForecastData().observe(this, new Observer<ForecastData>() {
            @Override
            public void onChanged(@Nullable ForecastData fd1) {
                //textView.setText(s);
                if(fd1!=null && fd1.getCurrently()!=null && fd1.getCurrently().getWindSpeed()!=null )
                wind.setText(df.format(fd1.getCurrently().getWindSpeed())+ " mph");
                if(fd1!=null && fd1.getCurrently()!=null && fd1.getCurrently().getPrecipIntensity()!=null )
                prec.setText(df.format(fd1.getCurrently().getPrecipIntensity()).toString()+" mmph");
                if(fd1!=null && fd1.getCurrently()!=null && fd1.getCurrently().getPressure()!=null )
                pres.setText(df.format(fd1.getCurrently().getPressure()).toString()+" mb");
                if(fd1!=null && fd1.getCurrently()!=null && fd1.getCurrently().getTemperature()!=null )
                temp.setText(Math.round(fd1.getCurrently().getTemperature())+"°F");
                if(fd1!=null && fd1.getCurrently()!=null && fd1.getCurrently().getSummary()!=null )
                summ.setText(fd1.getCurrently().getSummary().replace('-',' '));
                if(fd1!=null && fd1.getCurrently()!=null && fd1.getCurrently().getHumidity()!=null )
                hum.setText(Long.toString(Math.round(fd1.getCurrently().getHumidity()*100))+ " %");
                if(fd1!=null && fd1.getCurrently()!=null && fd1.getCurrently().getVisibility()!=null )
                visi.setText(df.format(fd1.getCurrently().getVisibility()).toString()+" km");
                if(fd1!=null && fd1.getCurrently()!=null && fd1.getCurrently().getCloudCover()!=null )
                cloud.setText(Long.toString(Math.round(fd1.getCurrently().getCloudCover()*100))+ " %");
                if(fd1!=null && fd1.getCurrently()!=null && fd1.getCurrently().getOzone()!=null )
                ozone.setText(df.format(fd1.getCurrently().getOzone()).toString()+" DU");


                String icn=fd.getCurrently().getIcon();
                if(icn.equalsIgnoreCase("clear-night")){
                    icon.setImageResource(R.drawable.weather_night);
                }
                else if(icn.equalsIgnoreCase("rain")){
                    icon.setImageResource(R.drawable.weather_rainy);
                }
                else if(icn.equalsIgnoreCase("sleet")){
                    icon.setImageResource(R.drawable.weather_snowy_rainy);
                }
                else if(icn.equalsIgnoreCase("snow")){
                    icon.setImageResource(R.drawable.weather_snowy);
                }
                else if(icn.equalsIgnoreCase("wind")){
                    icon.setImageResource(R.drawable.weather_windy_variant);
                }
                else if(icn.equalsIgnoreCase("fog")){
                    icon.setImageResource(R.drawable.weather_fog);
                }
                else if(icn.equalsIgnoreCase("cloudy")){
                    icon.setImageResource(R.drawable.weather_cloudy);
                }
                else if(icn.equalsIgnoreCase("partly-cloudy-night")){
                    icon.setImageResource(R.drawable.weather_night_partly_cloudy);
                }
                else if(icn.equalsIgnoreCase("partly-cloudy-day")){
                    icon.setImageResource(R.drawable.weather_partly_cloudy);
                }
                else{
                    icon.setImageResource(R.drawable.weather_sunny);
                }

            }
        });
        return root;
    }
}