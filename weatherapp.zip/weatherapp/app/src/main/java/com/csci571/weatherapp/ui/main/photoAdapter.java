package com.csci571.weatherapp.ui.main;

import android.content.Context;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.csci571.weatherapp.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;


public class photoAdapter extends RecyclerView.Adapter<photoAdapter.photoViewHolder> {
    private Context mContext;
    private ArrayList<photoitem> mExampleList;

    public photoAdapter(Context context, ArrayList<photoitem> exampleList) {
        mContext = context;
        mExampleList = exampleList;
    }

    @Override
    public photoViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(mContext).inflate(R.layout.photo_item, parent, false);
        return new photoViewHolder(v);
    }

    @Override
    public void onBindViewHolder(photoViewHolder holder, int position) {
        photoitem currentItem = mExampleList.get(position);

        String imageUrl = currentItem.getImageUrl();



        Picasso.get().load(imageUrl).into(holder.mImageView);
    }

    @Override
    public int getItemCount() {
        return mExampleList.size();
    }

    public class photoViewHolder extends RecyclerView.ViewHolder {
        public ImageView mImageView;
        public TextView mTextViewCreator;
        public TextView mTextViewLikes;

        public photoViewHolder(View itemView) {
            super(itemView);
            mImageView = itemView.findViewById(R.id.image_view);

        }
    }
}
