package com.csci571.weatherapp.ui.main;

public class photoitem {
    private String mImageUrl;
    private String mCreator;
    private int mLikes;

    public photoitem(String imageUrl) {
        mImageUrl = imageUrl;

    }

    public String getImageUrl() {
        return mImageUrl;
    }

}
